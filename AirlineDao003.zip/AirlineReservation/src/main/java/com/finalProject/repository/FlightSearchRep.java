/*package com.finalProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.finalProject.entity.FlightSearch;

@Repository
public interface FlightSearchRep extends JpaRepository<FlightSearch, Long>{
	
	@Query(value = "select f from flightsearch f where from_loc =?1 and to_loc =?2", nativeQuery=true)
	List<FlightSearch> findByFirstnameAndLastName(String from_loc, String to_loc);

}
*/